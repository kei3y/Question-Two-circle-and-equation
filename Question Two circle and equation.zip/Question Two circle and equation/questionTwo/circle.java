/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionTwo;

/**
 *
 * @author Kei3ron
 */
 import java.util.Scanner;
public class circle{
    private double radius;
    private final double pi = 22.0 / 7.0;

    public circle(double radius) {
        this.radius = radius;
    }

    public double calculateArea() {
        return pi * radius * radius;
    }

    public double calculateCircumference() {
        return 2 * pi * radius;
    }
}
