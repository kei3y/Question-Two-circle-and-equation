/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionTwo;

import java.util.Scanner;

/**
 *
 * @author Kei3ron
 */
public class areaAndCircumference {
    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = Scanner.nextDouble();

        circle circle = new circle(radius);

        double area = circle.calculateArea();
        double circumference = circle.calculateCircumference();

        System.out.println("Area of the circle is " + area);
        System.out.println("Circumference of the circle is " + circumference);

        Scanner.close();
    }
}
